/**
 *  Created By 憧憬
 */

export const FETCH = 'fetch';

export const DELETE = 'delete';


