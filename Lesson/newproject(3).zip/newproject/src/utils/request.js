import axios from "axios";

/**
 *  Created By 憧憬
 */
const axiosInstance = axios.create({
    timeout: 0.001,
});

axiosInstance.interceptors.request.use(function (config) {
    console.log('请求前')
    return config;
}, function (error) {
    return Promise.reject(error);
});

axiosInstance.interceptors.response.use(function (response) {
    console.log('响应后')
    return response;
}, function (error) {
    return Promise.reject(error);
});


class Request {
    static fetch = (url, method = 'GET') => {
        switch (method) {
            case 'GET':
                return axiosInstance.get(url);

            case 'POST':
                return axiosInstance.post(url);
        }
    }
}

export default Request;
