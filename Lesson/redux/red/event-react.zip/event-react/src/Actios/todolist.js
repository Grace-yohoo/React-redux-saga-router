/**
 *  Created By 憧憬
 */
import {FETCH, DELETE} from '../ActionTypes/todolist';

// action creator

/**
 * 创建一个删除的action
 * @param id
 * @returns {{payload: *, type: string}}
 */
export const createDeleteAction = id => {
    return {
        type: DELETE,
        payload: id
    };
};


/**
 * 创建一个fetch的action
 * @param res
 * @returns {{payload: *, type: string}}
 */
export const createFetchAction = res => {
    return {
        type: FETCH,
        payload: res
    };
};
