import {DELETE, FETCH} from "../ActionTypes/todolist";

/**
 *  Created By 憧憬
 */


const initState = {
    name: '张三',
    list: []
};


export const todoListReducer = (state = initState, action) => {
    switch (action.type) {
        case FETCH:
            return {
                ...state,
                list: action.payload
            };

        case DELETE:
            let {list} = state;
            list.forEach((item, index) => {
                if (item.id === action.payload) {
                    list.splice(index, 1);
                }
            });

            return {
                ...state,
                list,
            };

        default:
            return state;
    }
};

