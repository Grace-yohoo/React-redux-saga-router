/**
 *  Created By 憧憬
 */

const carouseState = {

};

export const carouselReducer = (state = carouseState, action) => {

    switch (action.type) {

    }


    return state;
};
