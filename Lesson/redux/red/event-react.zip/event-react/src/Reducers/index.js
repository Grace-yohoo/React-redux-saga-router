/**
 *  Created By 憧憬
 */
import {carouselReducer} from './carousel';
import {todoListReducer} from './todolist';

export default {
    carouselReducer,
    todoListReducer
};
