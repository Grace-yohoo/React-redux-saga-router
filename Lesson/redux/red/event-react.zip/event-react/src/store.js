/**
 *  Created By 憧憬
 */
import {
    createStore,
    combineReducers
} from 'redux';
import reduces from './Reducers';

const store = createStore(combineReducers(reduces));

console.log(store.getState())
export default store;
