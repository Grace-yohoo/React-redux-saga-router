import React from "react";
import store from '../store';
import {createDeleteAction, createFetchAction} from '../Actios/todolist';

export default class extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            list: store.getState().todoListReducer.list,
            isLoading: true,
        };

        store.subscribe(this.listen);

        this.maxId = 2;
    }



    componentDidMount() {
        fetch("http://jsonplaceholder.typicode.com/posts").then(res => {
            return res.json();
        }).then(res => {
            store.dispatch(createFetchAction(res))
        });


        // document.addEventListener('click', this.t, false);
        this.timer = setTimeout(() => {
            this.setState({
                isLoading: false
            })
        }, 3000);
    }

    componentWillUnmount() {
        clearInterval(this.timer)
    }

    listen = () => {
        this.setState({
            list: store.getState().todoListReducer.list
        })
    };

    delete = (id) => {
        store.dispatch(createDeleteAction(id));
    };

    add = (e) => {
        e.nativeEvent.stopImmediatePropagation();

        let {list} = this.state;

        let temp = [];
        list.forEach((item) => {
            temp.push(item.id);
        });

        let maxId = Math.max(...temp);

        if (maxId.toString() === '-Infinity') {
            maxId = this.maxId;
        }

        this.maxId = maxId + 1;

        let obj = {
            id: this.maxId,
            content: Math.random() * 10,
            date: (new Date()).toString().substr(10, 15)
        };

        list.push(obj);

        this.setState({
            list
        });
    };

    render() {

        const {
            list,
            isLoading,
        } = this.state;


        // console.log(list)

        // map
        return (
            <div className="App" style={{zIndex: 99999, overflow: 'hidden', width: '100%'}}>
                <h2>待办事项</h2>
                <button className="bottom" onClick={this.add}>增加</button>
                {
                    isLoading ? <Loading/> : <TodoList list={list} delete={this.delete} />
                }
            </div>

        );
    }
}



function TodoList(props) {

    let {
        list,
        delete: handleDelete
    } = props;

    return (
        <div>
            {
                list.map((item) => {
                    return (
                        <div className="p-style" key={item.id}>
                            <span>{item.title}</span>
                            <span>{item.body}</span>
                            <button onClick={() => handleDelete(item.id)}>删除</button>
                        </div>
                    )
                })
            }
        </div>
    );
}

function Loading() {

    return (
        <div>
            loading.....
        </div>
    );
}
