/**
 *  Created By 憧憬
 */
/*
    我随便写es6代码 能给及时在编译给予反馈
 */
import style from './a.css';

/**
 * 我要转换es6为es5 需要哪些包？
 */

/**
 * @babel/core babel 核心
 * @babel/runtime  被依赖
 * @babel/plugin-transform-runtime 解析最新es语法
 * @babel/preset-env  可以解析对应环境  web node

 yarn add -D @babel/core @babel/runtime @babel/plugin-transform-runtime @babel/preset-env
 */

let S = Symbol('sb');

console.log(S);

let a = async () => {
    // console.log(111)
    await 111;
    return 1;
};



// let obj = {
//     name: '李四'
// };
//
// let desc = Object.getOwnPropertyDescriptor(obj, 'name');
//
// Object.defineProperty(obj, 'name', {
//     writable: false,
//     configurable: false
// });

// obj.name = '张三';

// delete obj.name
// console.log(desc);


const typename = (target) => {
    console.dir(target)

    console.log(11111111);
    // return 1;

    target.test = 'abc';
};


let withLoading = (target, key, descriptor) => {

    console.log('loading 开始')
    let abc = target[key]();
    console.log('loading 结束')


    descriptor.value = function () {
        return 'descriptor' + abc;
    };


};

let log = (type) => {

    return (target, key, descriptor) => {
        console.log(`user 触发了${type}了 这个操作`)
    };
};


@typename
class Test{
    abc = '测试';


    @withLoading
    fetch() {
        console.log('fetch')
        return 'abc';
    }

    @log('click')
    click() {

    }

    @log('orderList')
    getOrderList() {

    }
}

// Test.test = 'abc';

console.log((new Test()).click());
console.log((new Test()).getOrderList());


console.log('test',Test);
a().then(res =>{
    console.log(res);
});
