import React from "react";

/**
 *  Created By 憧憬
 */

export default class extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            list: [
                {id: 1, content: '上午讲课', date: '9:00 - 12:00'},
                {id: 2, content: '下午讲课', date: '3:00 - 5:00'},
            ],

            isLoading: true
        };

        this.maxId = 2;
        // this.delete().bind()
        // this.delete = this.delete.bind(this);
    }

    componentDidMount() {

        setTimeout(() => {
            this.setState({
                isLoading: false
            })
        }, 3000);
    }

    delete = (id) => {
        let {list} = this.state;
        list.forEach((item, index) => {
            if (item.id === id) {
                list.splice(index, 1);
            }
        });

        this.setState({
            list,
        })
    };

    add = () => {
        let {list} = this.state;

        let temp = [];
        list.forEach((item) => {
            temp.push(item.id);
        });

        let maxId = Math.max(...temp);

        if (maxId.toString() === '-Infinity') {
            maxId = this.maxId;
        }

        this.maxId = maxId + 1;

        let obj = {
            id: this.maxId,
            content: Math.random() * 10,
            date: (new Date()).toString().substr(10, 15)
        };

        list.push(obj);

        this.setState({
            list
        });

    };


    render() {

        const {
            list,
            isLoading
        } = this.state;


        console.log(list)

        // map
        return (
            <div className="App">
                <h2>待办事项</h2>
                <button className="bottom" onClick={this.add}>增加</button>
                {
                    isLoading ? <Loading/> : <TodoList list={list} delete={this.delete} />
                }
            </div>
        );
    }
}

function TodoList(props) {

    let {
        list,
        delete: handleDelete
    } = props;

    return (
        <div>
            {
                list.map((item) => {
                    return (
                        <div className="p-style" key={item.id}>
                            <span>{item.content}</span>
                            <span>{item.date}</span>
                            <button onClick={() => handleDelete(item.id)}>删除</button>
                        </div>
                    )
                })
            }
        </div>

    );
}

function Loading() {

    return (
        <div>
            Loading.....
        </div>
    );
}
