/**
 *  Created By 憧憬
 */
import React, {useState, useEffect} from 'react';

export default function () {

    const [state, setState] = useState({name: '张三'});

    useEffect(() => {
        console.log(11)
    });

    return (
        <div>
            <div>{state.name}</div>

            <button onClick={() => setState({name: '李四'})}>click</button>
        </div>
    )
}
