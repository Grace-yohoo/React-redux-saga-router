//数据库配置文件
const config = {
    database :'mysql',
    username:'root',
    password:'123456',
    host:'localhost',
    port:3306
}

module.exports = config;