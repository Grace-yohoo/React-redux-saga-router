import React from "react";
import Request from '../utils/request';
import Loadable from 'react-loadable';


// const LoadableComponent = Loadable({
//     loader: () => import('../TodoList/index.js'),
//     loading: <div>loading</div>,
// });

/**
 *  Created By 憧憬
 */
export default class extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            name: '张三',
            count: 0,
            data: []
        };
        console.log('构造函数')
    }

    static getDerivedStateFromProps() {
        console.log('getDerivedStateFromProps render之前')
        return {};
    }

    componentDidMount() {
        // 接口请求 获取数据
        console.log('render 之后');
        Request.fetch('http://jsonplaceholder.typicode.com/posts').then(res => {
            console.log(res);
        })
        // fetch('http://jsonplaceholder.typicode.com/posts').then(res => {
        //     // console.log(res)
        //     return res.json();
        // }).then(res => {
        //     console.log(res);
        //     this.setState({
        //         data:res
        //     })
        // })
    }

    // 组件是否应该更新
    shouldComponentUpdate() {
        console.log('shouldComponentUpdate 组件是否应该渲染')
        return true;
    }

    getSnapshotBeforeUpdate(prevProps, prevState) {
        console.log('getSnapshotBeforeUpdate update之前')
        return 1;
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        console.log(snapshot)
        console.log('componentDidUpdate  ')
    }

    incrementCount = () => {
        // this.setState({
        //     count: this.state.count + 1
        // })


        this.setState((prevState) => {
            console.log(prevState)
            return {
                count: prevState.count + 1
            };
        });

        // this.forceUpdate();
    };

    click = () => {
        this.incrementCount();
        // console.log(1)
        // this.incrementCount();
        // console.log(2)
        // this.incrementCount();
        // console.log(3)
        // this.incrementCount();
    };

    render() {

        console.log('render中');
        const {
            name,
            count,
            data
        } = this.state;

        console.log(data);
        return (
            <div>
                <input type="text"/>
                setState
                <h1>{name}</h1>

                <h2>{count}</h2>
                <button onClick={this.click}>click</button>
            </div>
        );
    }
}
