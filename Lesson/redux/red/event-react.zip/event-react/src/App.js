import React from 'react';
import TodoList from './Components/TodoList';
import logo from './logo.svg';
import './App.css';




class App extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className="App">
                <TodoList />
            </div>
        );
    }
}

export default App;
